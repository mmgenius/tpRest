package com.mycompany.mavenprojecttest.resources;

import Metier.Manager;
import Metier.Services;
import Metier.Utilisateur;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import javax.ws.rs.core.Response;

/**
 *
 * @author 
 */
@Path("services")
public class JavaEE8Services {
     
  
    @Path("{id}")
    @GET  
    @Produces(MediaType.APPLICATION_XML)
    public Response specificServices(@PathParam("id") String id )
    {
        Services resultService = null; 
        for(Services service:Manager.m_listServices)
        {
            if(service.getId().equals(id))
                resultService = service ; 
        }
        if(resultService != null)
            return Response.ok(resultService.toXML()).build();
        else
            return Response.ok("<SERVICE Id=\"NONE\" Service=\"NONE\" Fournisseur=\"NONE\" />").build();
    }
    
    @GET 
    @Produces(MediaType.APPLICATION_XML)
    public String listService()
    {
        String listService = "<SERVICES>"; 
        for(Services service:Manager.m_listServices)
        {
            listService += service.toXML(); 
        }
        listService += "</SERVICES>";
        return listService;
    }
    
    @Path("create")
    @POST  
    public Response create(String content)
    {
      String created = "";
      if(content != null)
      {
        if(Manager.addServices(new Services(content)))
            created = "CREATED"; 
        else
            created = "NOT CREATED";
      }
              
       return Response.ok("Service : " + content + " ----> " + created).build();
    }
    
    @Path("Delete")
    @DELETE
    public Response delete(String content)
    {
        String deleted = "";
        if(content != null)
        {
            if(Manager.deleteSerive(new Services(content)))
            {
                deleted = "DELETED";
            }
            else
            {
                deleted = "NOT DELETED"; 
            }
        }
        
        return Response.ok("DELETING SERVICE: " + content + " ----> " + deleted).build();
    }
    
    @Path("listServices/{idUser}")
    @GET 
    @Produces(MediaType.APPLICATION_XML)
    public String listServiceByid(@PathParam("idUser") String idUser)
    {
        String listService = "<SERVICES>"; 
        List<Services> listServiceSpecifi = new ArrayList<Services>();
        for(Services service:Manager.m_listServices)
        {
            if(idUser == service.getFournisseur())
            {
              listServiceSpecifi.add(service);
            }            
        }
        for(Services service:listServiceSpecifi)
        {
            listService += service.toXML();
        }
        listService += "</SERVICES>";
        return listService;
    }
   
      
}
