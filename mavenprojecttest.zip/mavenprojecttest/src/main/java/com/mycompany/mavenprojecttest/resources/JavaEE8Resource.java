package com.mycompany.mavenprojecttest.resources;

import Metier.Manager;
import Metier.Services;
import Metier.Utilisateur;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import javax.ws.rs.core.Response;

/**
 *
 * @author 
 */
@Path("utilisateurs")
public class JavaEE8Resource {
     
  
    @Path("{id}")
    @GET  
    @Produces(MediaType.APPLICATION_XML)
    public Response specificUser(@PathParam("id") String id )
    {
        Utilisateur resultUser = null; 
        for(Utilisateur user:Manager.m_listUsers)
        {
            if(user.getId().equals(id))
                resultUser = user ; 
        }
        if(resultUser != null)
            return Response.ok(resultUser.toXML()).build();
        else
            return Response.ok("Utilisateur : NONE").build();
    }
    
    @GET 
    @Produces(MediaType.APPLICATION_XML)
    public String listUser()
    {
        String listUser = "<UTILISATEURS>"; 
        for(Utilisateur user:Manager.m_listUsers)
        {
            listUser += user.toXML(); 
        }
        listUser += "</UTILISATEURS>";
        return listUser;
    }
    
    @Path("create")
    @POST
    public Response create(String content)
    {
       String created = "";
      if(content != null)
      {
        if(Manager.addUser(new Utilisateur(content)))
            created = "CREATED"; 
        else
            created = "NOT CREATED";
      }
              
       return Response.ok("Service : " + content + " ----> " + created).build();
    }
   
    @Path("Delete")
    @DELETE
    public Response delete(String content)
    {
        String deleted = "";
        if(content != null)
        {
            if(Manager.deleteUser(new Utilisateur(content)))
            {
                deleted = "DELETED";
            }
            else
            {
                deleted = "NOT DELETED"; 
            }
        }
        
        return Response.ok("DELETING SERVICE: " + content + " ----> " + deleted).build();
    }
    
      
}
