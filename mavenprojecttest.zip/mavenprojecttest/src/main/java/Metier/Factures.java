/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metier;

/**
 *
 * @author AdminEtu
 */
public class Factures {
     protected static int m_iCounter = 0;
    protected String m_strId, m_strUserId, m_strServiceId ; 
    
    public Factures(String xml)
    {
        m_strId = findAttribute(xml, "ID");
        m_strUserId = findAttribute(xml, "USER");
        
        m_strServiceId = findAttribute(xml, "SERVICE");
        if(m_strId == null)
            m_strId = getNewId();
        
    }
    
    public static String getNewId()
    {
        return "" + (m_iCounter++);
    }
    
    public static String findAttribute(String xml, String idAttribute)
    {
        int pos1 = xml.indexOf(idAttribute + "=\"");
        if(pos1 < 0) return null ; 
        int pos2 = xml.indexOf("\"", pos1 + idAttribute.length() + 2);
        return xml.substring(pos1 + idAttribute.length() + 2, pos2);
        
    }
    
    public String toXML()
    {
        return "<FACTURE ID=\"" + m_strId + "\" USER=\"" + m_strUserId + "\" SERVICE=\""+ m_strServiceId + "\" />"; 
    }
    
    public String getId()
    {
        return m_strId; 
    }
    
}
