/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metier;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author AdminEtu
 */
public class Manager {
    
    public static List<Utilisateur> m_listUsers;
    public static List<Services> m_listServices; 
    
    static
    {
        m_listUsers = new ArrayList<Utilisateur>(); 
        m_listServices = new ArrayList<Services>(); 
    }
    //Ajout d'un utilisateurs
    public static boolean addUser(Utilisateur lamda)
    {
        boolean added = false ; 
        if(!m_listUsers.contains(lamda))
        {
            m_listUsers.add(lamda);
            added = true; 
        }
              
        return added;
    }
    //Ajout d'un service
    public static boolean addServices(Services lamda)
    {
        boolean added = false ; 
       if(!m_listServices.contains(lamda))
       {
           m_listServices.add(lamda);
           added = true; 
       }
              
        return added;
    }
    //Supprimer un utilisateur
    public static boolean deleteUser(Utilisateur user)
    {
        boolean deleted = false ; 
        if(m_listUsers.contains(user))
        {
            deleted = m_listUsers.remove(user);
        }
        
        return deleted ; 
    }
    
    //Supprimer un service
    public static boolean deleteSerive(Services service)
    {
        boolean deleted = false ; 
        if(m_listServices.contains(service))
        {
            deleted = m_listServices.remove(service);
        }
        return deleted ; 
    }
    
    
    public static int countUser()
    {
        return m_listUsers.size(); 
    }
    
    public static int countServices()
    {
        return m_listServices.size();
    }
}
