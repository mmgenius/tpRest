/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metier;

/**
 *
 * @author AdminEtu
 */
public class Services {
    protected static int m_iCounter = 0; 
    private String m_strName, m_strId, m_strUserId; 
    
    public Services(String xml)
    {
        m_strName = findAttribute(xml, "Service");
        m_strId = findAttribute(xml, "Id");
        
        m_strUserId = findAttribute(xml, "Fournisseur");
        if(m_strId == null)
            m_strId = getNewId();
    }
    
    public static String getNewId()
    {
        return "" + (m_iCounter++);
    }
    
    public static String findAttribute(String xml, String idAttribute)
    {
        int pos1 = xml.indexOf(idAttribute + "=\"");
        if(pos1 < 0) return null ; 
        int pos2 = xml.indexOf("\"", pos1 + idAttribute.length() + 2);
        return xml.substring(pos1 + idAttribute.length() + 2, pos2);
        
    }
    
    public String toXML()
    {
        return "<SERVICE Id=\"" + m_strId + "\" Service=\"" + m_strName + "\" fournisseur=\""+ m_strUserId + "\" />";  
    }
    
    public String getNom()
    {
        return m_strName; 
    }
    
    public String getId()
    {
        return m_strId; 
    }
    
    public String getFournisseur()
    {
        return m_strUserId; 
    }
}
