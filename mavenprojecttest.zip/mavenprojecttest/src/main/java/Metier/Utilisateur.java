/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metier;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author AdminEtu
 */
public class Utilisateur {
    protected static int idCounter = 0;
    protected String m_strNom, m_strPrenom, m_strID ; 
    protected List<Services> m_listServices ; 
    
    public Utilisateur(String xml)
    {
        m_strNom = findAttribute(xml, "NOM");
        m_strPrenom = findAttribute(xml, "PRENOM");
        
        m_strID = findAttribute(xml, "ID");
        
        m_listServices = new ArrayList<Services>(); 
               
    }
    
    public static String getNewId()
    {     
        return "" + (idCounter++);
    }
    
    public static String findAttribute(String xml, String idAttribute)
    {
        int pos1 = xml.indexOf(idAttribute + "=\"");
        if(pos1 < 0) return null ; 
        int pos2 = xml.indexOf("\"", pos1 + idAttribute.length() + 2);
        return xml.substring(pos1 + idAttribute.length() + 2, pos2);
        
    }
    
    public String toXML()
    {
        return "<UTILISATEUR ID=\"" + m_strID + "\" NOM=\"" + m_strNom + "\" PRENOM=\""+ m_strPrenom + "\" />";    
    }
    
    public String getNom()
    {
        return m_strNom; 
    }
    
    public String getPrenom()
    {
        return m_strPrenom; 
    }
    
    public String getId()
    {
        return m_strID; 
    }
    
    public boolean addServiceRecu(Services service)
    {
        m_listServices.add(service);
        
        return m_listServices.contains(service);
    }
    
    public boolean deleteServiceRecu(Services service)
    {
        boolean deleted = false ; 
        if(m_listServices.contains(service))
        {
            deleted = m_listServices.remove(service);
        }
        
        return deleted ; 
    }
}
